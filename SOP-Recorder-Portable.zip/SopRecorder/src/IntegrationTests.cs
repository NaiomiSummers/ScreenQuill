using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace SopRecorder
{
    internal sealed class DummyWindow : Form
    {
        internal DummyWindow(string name)
        {
            Text = "SOP test app " + name; Size = new Size(640, 450); Location = new Point(name == "A" ? 20 : 670, 30); StartPosition = FormStartPosition.Manual; BackColor = name == "A" ? Color.LemonChiffon : Color.Honeydew;
            TableLayoutPanel grid = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(25), RowCount = 4, ColumnCount = 1 };
            grid.Controls.Add(new Label { Text = "Dummy app " + name + " — grocery checklist", AutoSize = true, Font = new Font("Segoe UI", 18) });
            grid.Controls.Add(new TextBox { Text = "Milk, Bread, Apples", Dock = DockStyle.Top }); grid.Controls.Add(new TextBox { Text = "Check the list", Dock = DockStyle.Top }); grid.Controls.Add(new Button { Text = "Review list", AutoSize = true }); Controls.Add(grid);
        }
    }
    internal sealed class FakeClock : IClock
    {
        internal double Value; internal DateTimeOffset Base = new DateTimeOffset(2026, 11, 25, 12, 0, 0, TimeSpan.FromHours(-7));
        public double Now { get { return Value; } } public DateTimeOffset Wall { get { return Base.AddSeconds(Value); } }
    }
    internal sealed class DummyFrames : IFrameSource
    {
        internal int Count, Slow; internal string App = "Dummy app A";
        public Step Take(CaptureTarget target, string directory, CancellationToken token)
        {
            token.ThrowIfCancellationRequested(); int n = Interlocked.Increment(ref Count); SystemClock clock = new SystemClock();
            Step frame = new Step { Captured = clock.Wall, Mono = clock.Now, Sequence = n, Source = "Synthetic test display — " + App };
            if (Slow > 0) { Thread.Sleep(Slow); token.ThrowIfCancellationRequested(); }
            frame.File = Path.Combine(directory, "dummy-" + n + ".png");
            using (Bitmap b = new Bitmap(800, 430)) using (Graphics g = Graphics.FromImage(b)) using (Font font = new Font("Segoe UI", 20))
            { g.Clear(App.EndsWith("A") ? Color.LemonChiffon : Color.Honeydew); g.DrawString(App + "\n\nGrocery checklist\nMilk\nBread\nApples\n\nGenerated dummy evidence " + n, font, Brushes.Black, 30, 25); b.Save(frame.File, ImageFormat.Png); }
            return frame;
        }
    }
    internal static class IntegrationTests
    {
        internal static int ExitCode = 1;
        private static readonly List<string> results = new List<string>();
        private static string report;
        private static void Check(bool ok, string message) { if (!ok) throw new Exception("FAIL: " + message); results.Add("PASS: " + message); if (report != null) File.AppendAllText(report, "PASS: " + message + Environment.NewLine); }
        private static void Info(string s) { results.Add("INFO: " + s); if (report != null) File.AppendAllText(report, "INFO: " + s + Environment.NewLine); }
        private static byte[] Bytes(ZipArchiveEntry e) { using (Stream s = e.Open()) using (MemoryStream m = new MemoryStream()) { s.CopyTo(m); return m.ToArray(); } }
        private static string Text(ZipArchive z) { return Encoding.UTF8.GetString(Bytes(z.GetEntry("procedure.md"))); }
        private static string Press(TriggerPolicy p, int key, double time, bool scope) { string reason = p.Key(key, true, scope, time); p.Key(key, false, scope, time); return reason; }
        private static void PolicyTests()
        {
            TriggerPolicy p = new TriggerPolicy(); Check(p.Idle == 2, "Typing idle default is two seconds.");
            Check(Press(p, 65, 0, true) == "Typing burst", "First typing event captures the burst start promptly.");
            Check(Press(p, 66, 1, true) == null && Press(p, 67, 2.8, true) == null, "Continuous typing below the idle threshold does not capture again.");
            Check(Press(p, 68, 4.8, true) == "Typing burst", "A new burst starts after two seconds since the last typing event.");
            Check(Press(p, 9, 4.9, true) == "Focus change" && Press(p, 69, 5, true) == null, "Tab captures mid-burst without resetting or ending that burst.");
            Check(Press(p, 9, 7.1, true) == "Focus change" && Press(p, 70, 7.11, true) == "Typing burst", "Tab followed immediately by typing after idle yields both independent triggers.");
            p.Key(160, true, true, 7.2); Check(Press(p, 9, 7.2, true) == "Focus change", "Shift+Tab is captured as a discrete focus change."); p.Key(160, false, true, 7.2);
            Check(p.Key(9, true, true, 7.3) == "Focus change" && p.Key(9, true, true, 8) == null, "Held Tab auto-repeat is ignored."); p.Key(9, false, true, 8);
            Check(p.Key(71, true, true, 10) == "Typing burst" && p.Key(71, true, true, 20) == null, "Typing key auto-repeat does not create bursts."); p.Key(71, false, true, 20);
            Check(Press(p, 16, 20, true) == null && Press(p, 17, 20, true) == null, "Modifier-only events never capture.");
            p.Key(162, true, true, 20); Check(Press(p, 86, 20, true) == null, "Control shortcuts are ignored without reading clipboard contents."); p.Key(162, false, true, 20);
            Check(Press(p, 65, 30, false) == null, "Recorder controls and events outside the selected scope are ignored.");
            p.Reset(); Check(Press(p, 65, 30.01, true) == "Typing burst", "Resume/reset starts a fresh typing burst.");
        }
        private static void TimingTests(string directory)
        {
            FakeClock clock = new FakeClock();
            using (Session s = new Session(clock))
            {
                s.Start(); clock.Value = 2;
                Step first = new Step { Mono = 2, Captured = clock.Wall, File = MakeImage(s.DirectoryPath, "first", Color.LightBlue), Sequence = 1 }; s.Add(first);
                clock.Value = 5; s.Pause(); clock.Value = 9; s.Start(); clock.Value = 12;
                Step middle = new Step { Mono = 12, Captured = clock.Wall, File = MakeImage(s.DirectoryPath, "removed", Color.Red), Sequence = 2, ReviewedPath = "REMOVED-PATH.txt", PathEvidence = "Manual" }; s.Add(middle);
                clock.Value = 14; Step last = new Step { Mono = 14, Captured = clock.Wall, File = MakeImage(s.DirectoryPath, "last", Color.LightGreen), Sequence = 3 }; s.Add(last);
                clock.Value = 16; s.Stop(); Check(s.Elapsed == 16 && s.Active == 12, "Monotonic totals: 16s elapsed, 12s active, 4s paused.");
                s.Steps.Remove(middle); s.Steps.Reverse(); string summary = Durations.Summary(s);
                Check(summary.Contains("Before first retained capture (active): 2.000 s") && summary.Contains("After last retained capture (active): 2.000 s"), "Before-first and after-last capture time are separate.");
                Check(summary.Contains("step 2 to step 1 (capture chronology): 8.000 s") && summary.Contains("Longest interval: step 2 to step 1 (capture chronology), 8.000 s"), "Reordering and deleting preserve original capture timing and longest retained interval.");
                Check(summary.Contains("Time between retained captures") && 2 + 8 + 2 == s.Active, "Deleted captures are omitted; retained intervals plus edges equal active time.");
                string zipPath = Path.Combine(directory, "timing-and-deletion.zip"); Exporter.Write(s, zipPath, true);
                using (ZipArchive zip = ZipFile.OpenRead(zipPath))
                {
                    string md = Text(zip); Check(!md.Contains("REMOVED-PATH") && !md.Contains(middle.Stamp) && zip.Entries.Count == 3, "Deleted image, its path and timestamp are absent from the evidence ZIP.");
                    Check(md.Contains(last.Stamp) && md.Contains(first.Stamp) && md.Contains("images/001.png") && md.Contains("images/002.png"), "Image references carry the correct capture dates, seconds and UTC offsets after reorder.");
                    using (MemoryStream m = new MemoryStream(Bytes(zip.GetEntry("images/001.png")))) using (Bitmap b = new Bitmap(m))
                    { Check(b.Height > 200 && b.Width >= 420 && b.GetPixel(20, 20).G > b.GetPixel(20, 20).R, "Export image order matches retained images and each PNG has a separate footer below the image."); b.Save(Path.Combine(directory, "footer-preview.png"), ImageFormat.Png); }
                }
                clock.Base = clock.Base.AddHours(-3); Check(s.Elapsed == 16 && s.Active == 12, "Wall-clock changes do not affect monotonic durations.");
            }
            using (Session s = new Session(new FakeClock()))
            {
                s.Start(); Step earlier = new Step { Mono = 1, Sequence = 1 }, later = new Step { Mono = 3, Sequence = 2 };
                s.Add(later); s.Add(earlier); Check(s.Steps[0] == earlier && s.Steps[1] == later, "Results completing out of order are stored in original acquisition chronology.");
            }
        }
        private static string MakeImage(string directory, string name, Color color)
        { string file = Path.Combine(directory, name + ".png"); using (Bitmap b = new Bitmap(500, 200)) using (Graphics g = Graphics.FromImage(b)) { g.Clear(color); b.Save(file, ImageFormat.Png); } return file; }
        private static void Trigger(RecorderForm app, string reason, int delay) { if (reason != null) app.Engine.Request(reason, delay, false); }
        internal static async Task Run(RecorderForm app, string directory)
        {
            Directory.CreateDirectory(directory); report = Path.Combine(directory, "test-results.txt"); File.WriteAllText(report, ""); Process a = null, b = null; int viewerPid = 0;
            try
            {
                PolicyTests(); TimingTests(directory);
                app.Session.Dispose(); DummyFrames frames = new DummyFrames(); app.SetupSession(frames); app.Target = CaptureTarget.Default(""); app.Engine.Target = app.Target;
                Check(app.Target.IsDisplay && app.Target.DisplayName == Screen.PrimaryScreen.DeviceName, "Record Screen defaults to the primary display without window selection.");
                Check(CaptureTarget.Default("invalid-disconnected-monitor").DisplayName == Screen.PrimaryScreen.DeviceName, "A missing last display selection falls back to primary before recording.");
                using (TargetPicker picker = new TargetPicker(app.Target))
                {
                    picker.Shown += delegate { picker.BeginInvoke(new Action(delegate { picker.Use.PerformClick(); })); };
                    Check(picker.ShowDialog(app) == DialogResult.OK && picker.Choice.IsDisplay && picker.Choice.DisplayName == app.Target.DisplayName, "Display picker confirms the selected display through its actual controls.");
                }
                app.Record.PerformClick(); Check(app.Session.State == SessionState.Recording && app.TaskName.Text == "", "One Record Screen click starts recording with no task name or overview.");
                Info("Native low-level input hooks: available=" + app.HooksAvailable + ", Win32 error=" + app.HookError + ". Physical input cannot be injected in this chat; dispatch/policy tests use transient synthetic events.");
                TriggerPolicy policy = new TriggerPolicy();
                Trigger(app, "Mouse click", 80); await app.Engine.Drain(); Check(app.Session.Steps.Count == 1, "A discrete click dispatch makes one delayed capture.");
                frames.App = "Dummy app B"; Trigger(app, "Mouse click", 80); await app.Engine.Drain(); Check(app.Session.Steps.Count == 2 && app.Session.Steps[1].Source.EndsWith("B"), "Display capture dispatch continues across simulated app switches.");
                Trigger(app, Press(policy, 65, 0, true), 0); Trigger(app, Press(policy, 66, .5, true), 0); Trigger(app, Press(policy, 67, 1, true), 0); await app.Engine.Drain();
                Check(app.Session.Steps.Count == 3, "Continuous typing produces only one prompt burst-start screenshot.");
                Trigger(app, Press(policy, 68, 3.1, true), 0); await app.Engine.Drain(); Check(app.Session.Steps.Count == 4, "Typing after idle creates a new burst screenshot.");
                int before = app.Session.Steps.Count; Trigger(app, Press(policy, 9, 6, true), 180); Trigger(app, Press(policy, 69, 6.01, true), 0); await app.Engine.Drain();
                Check(app.Session.Steps.Count == before + 2 && app.Session.Steps[before].Reason == "Typing burst" && app.Session.Steps[before + 1].Reason == "Focus change", "Tab plus immediate typing both capture, sorted by actual acquisition time rather than trigger time.");
                policy.Key(160, true, true, 6.1); Trigger(app, Press(policy, 9, 6.1, true), 50); policy.Key(160, false, true, 6.1); await app.Engine.Drain(); Check(app.Session.Steps.Last().Reason == "Focus change", "Shift+Tab dispatch creates a screenshot even mid-burst.");
                before = app.Session.Steps.Count; int filesBefore = Directory.GetFiles(app.Session.DirectoryPath).Length; Trigger(app, "Mouse click", 350); app.Pause.PerformClick(); await app.Engine.Drain();
                Trigger(app, "Mouse click", 0); Trigger(app, "Typing burst", 0); await app.Engine.Drain(); Check(app.Session.State == SessionState.Paused && app.Session.Steps.Count == before && Directory.GetFiles(app.Session.DirectoryPath).Length == filesBefore, "Pause cancels a pending delayed capture and all paused triggers create no PNG or step.");
                app.Pause.PerformClick(); frames.Slow = 150; Trigger(app, "Typing burst", 0); await Task.Delay(30); app.Stop.PerformClick(); await app.Engine.Drain(); frames.Slow = 0;
                Check(app.Session.State == SessionState.Review && app.Session.Steps.Count == before && Directory.GetFiles(app.Session.DirectoryPath).Length == filesBefore, "Stop cancels in-flight acquisition; no image leaks into storage or review.");
                Trigger(app, "Mouse click", 0); await app.Engine.Drain(); Check(app.Session.Steps.Count == before, "Stopped triggers are disabled.");
                app.Record.PerformClick(); string fixture = Path.Combine(app.Session.DirectoryPath, "grocery-fixture.txt"); File.WriteAllText(fixture, "Dummy groceries\r\nMilk\r\nBread\r\nApples");
                await app.OpenTracked(fixture); viewerPid = app.ViewerPid;
                Step fileStep = app.Session.Steps.SingleOrDefault(s => !s.HasImage && s.Reason == "File opened");
                if (fileStep == null) { Info("Viewer diagnostic: " + app.Feedback.Text + "; bounds=" + app.Target.Bounds); if (File.Exists(fixture + ".viewer-error.txt")) Info(File.ReadAllText(fixture + ".viewer-error.txt")); }
                if (fileStep != null && !string.Equals(fileStep.ReviewedPath, Path.GetFullPath(fixture), StringComparison.OrdinalIgnoreCase)) Info("Verified canonical test path differs from requested spelling: " + fileStep.ReviewedPath + " / requested " + fixture);
                Check(fileStep != null && Path.IsPathRooted(fileStep.ReviewedPath) && File.Exists(fileStep.ReviewedPath) && File.ReadAllText(fileStep.ReviewedPath) == File.ReadAllText(fixture) && fileStep.PathEvidence.StartsWith("Verified open"), "Supported viewer workflow reads a real local file and verifies its canonical full path from the same file handle.");
                Kill(viewerPid); viewerPid = 0;
                int beforeFile = app.Session.Steps.Count;
                Task pausedOpen = app.OpenTracked(fixture, 500); viewerPid = app.ViewerPid; await Task.Delay(30); app.Pause.PerformClick(); await pausedOpen;
                await ViewerLoaded(viewerPid); Check(app.Session.State == SessionState.Paused && app.Session.Steps.Count == beforeFile && !Directory.GetFiles(app.Session.DirectoryPath).Any(f => f.Contains(".file-open")), "Pause revokes pending file-open evidence; a late successful file load adds no step or metadata handoff."); Kill(viewerPid); viewerPid = 0;
                app.Pause.PerformClick(); Task stoppedOpen = app.OpenTracked(fixture, 500); viewerPid = app.ViewerPid; await Task.Delay(30); app.Stop.PerformClick(); await stoppedOpen;
                await ViewerLoaded(viewerPid); Check(app.Session.State == SessionState.Review && app.Session.Steps.Count == beforeFile && !Directory.GetFiles(app.Session.DirectoryPath).Any(f => f.Contains(".file-open")), "Stop also revokes late file-open tracking with no retained path or handoff."); Kill(viewerPid); viewerPid = 0;
                app.RefreshSteps(fileStep.Id); app.PathEntry.Text = "grocery-fixture.txt";
                Check(fileStep.PathEvidence.StartsWith("Manually") && !app.Reviewed.Checked, "Shortening a verified path marks it edited and invalidates review.");
                app.PathEntry.Clear(); Check(fileStep.ReviewedPath == "", "Review can completely remove a file path.");
                app.Goal.Text = "Prepare a grocery list across two apps."; app.Note.Text = "Viewed the dummy text file; original full path removed during review.";
                Step deleted = app.Session.Steps.First(s => s.HasImage); deleted.ReviewedPath = "REMOVE-THIS-PATH.txt"; app.RefreshSteps(deleted.Id); app.Remove.PerformClick();
                Check(!app.Session.Steps.Contains(deleted) && !app.Reviewed.Checked, "Remove deletes the selected step and its path from retained evidence.");
                app.Undo.PerformClick(); Check(app.Session.Steps.Contains(deleted), "Undo restores the last removed step."); app.Remove.PerformClick();
                Step image = app.Session.Steps.First(s => s.HasImage); app.RefreshSteps(image.Id); app.PathEntry.Text = "manual-location.txt"; app.Note.Text = "Check the list before continuing."; app.Down.PerformClick();
                bool rejected = false; try { app.ExportTo(Path.Combine(directory, "unreviewed.zip")); } catch (InvalidOperationException) { rejected = true; } Check(rejected, "Export refuses evidence without review confirmation.");
                app.Reviewed.Checked = true; string export = Path.Combine(directory, "automatic-workflow.zip"); app.ExportTo(export); app.ExportTo(export);
                using (ZipArchive zip = ZipFile.OpenRead(export))
                {
                    string md = Text(zip); int imageCount = app.Session.Steps.Count(s => s.HasImage);
                    Check(zip.Entries.Count == imageCount + 1 && zip.Entries.All(e => e.FullName == "procedure.md" || (e.FullName.StartsWith("images/") && e.FullName.EndsWith(".png"))), "Evidence ZIP contains only retained numbered PNGs and Markdown, never opened files or input logs.");
                    Check(!md.Contains("REMOVE-THIS-PATH") && !md.Contains(Exporter.Escape(fixture)) && !md.Contains("Reviewed file location (Verified open"), "Removed paths and original shortened/cleared paths are absent from Markdown.");
                    Check(md.Contains("manual-location.txt") && md.Contains("Manually entered or edited") && md.Contains(app.Goal.Text), "Reviewed manual paths and the optional overview are exported accurately.");
                    Check(!md.Contains("vkCode") && !md.Contains("keyCode") && !md.Contains("clipboard") && !Directory.GetFiles(app.Session.DirectoryPath).Any(f => f.EndsWith(".log")), "No key codes, typed-text log, clipboard content or raw input logs are stored or exported.");
                    int number = 0;
                    foreach (Step s in app.Session.Steps.Where(s => s.HasImage))
                    {
                        string name = "images/" + (++number).ToString("D3") + ".png"; Check(zip.GetEntry(name) != null && md.Contains("[" + name + "](" + name + ") — Captured " + s.Stamp), "Numbered image " + number + " has the matching Markdown timestamp and reference.");
                        using (Image raw = Image.FromFile(s.File)) using (MemoryStream data = new MemoryStream(Bytes(zip.GetEntry(name)))) using (Image output = Image.FromStream(data)) Check(output.Height > raw.Height, "Numbered image " + number + " includes a timestamp footer below the captured pixels.");
                    }
                }
                Check(!app.Dirty, "Atomic overwrite/re-export succeeds and clears the unsaved marker.");
                // Keep test artifacts free of unrelated desktop content: live native pixels are used only transiently, never bundled.
                try
                {
                    Step screen = await Task.Run(delegate { return new WindowsCapture().Take(CaptureTarget.Default(""), app.Session.DirectoryPath, CancellationToken.None); });
                    using (Image raw = Image.FromFile(screen.File)) Check(raw.Size == Screen.PrimaryScreen.Bounds.Size, "Native full-display acquisition produces the selected display's pixel dimensions.");
                    Files.Delete(screen.File); Info("Native display pixels were discarded after dimension verification; exported workflow images are synthetic dummy fixtures.");
                }
                catch (Exception ex) { Info("WINDOWS CHECK STILL NEEDED: live full-display acquisition unavailable here: " + ex.Message); }
                a = Process.Start(new ProcessStartInfo(Application.ExecutablePath, "--dummy-window A") { UseShellExecute = false }); b = Process.Start(new ProcessStartInfo(Application.ExecutablePath, "--dummy-window B") { UseShellExecute = false });
                List<WindowChoice> windows = new List<WindowChoice>();
                for (int retry = 0; retry < 25; retry++) { await Task.Delay(100); windows = WindowChoice.List().Where(w => w.Pid == a.Id || w.Pid == b.Id).ToList(); if (windows.Count == 2) break; }
                Check(windows.Count == 2, "Two independent native dummy application processes expose selectable windows.");
                using (Session nativeSession = new Session(new SystemClock()))
                {
                    nativeSession.Name = "Native window capture smoke test"; nativeSession.Goal = "Verify native screenshot pixels for two independent dummy app windows; physical input delivery is not exercised."; nativeSession.Start();
                    foreach (WindowChoice w in windows)
                    {
                        Step frame = await Task.Run(delegate { return new WindowsCapture().Take(new CaptureTarget { Window = w }, nativeSession.DirectoryPath, CancellationToken.None); }); frame.Reason = "Native window API smoke test"; frame.Note = w.Title;
                        using (Bitmap bitmap = new Bitmap(frame.File))
                        { HashSet<int> colors = new HashSet<int>(); for (int y = 0; y < bitmap.Height; y += 10) for (int x = 0; x < bitmap.Width; x += 10) colors.Add(bitmap.GetPixel(x, y).ToArgb()); Check(colors.Count > 5, "Native dummy window image contains rendered controls and text colors, rather than a blank surface."); }
                        Check(frame.HasImage && frame.Mono > 0 && frame.Captured.Offset == DateTimeOffset.Now.Offset, "Optional window mode captures dummy app " + w.Title + " with acquisition timestamps."); nativeSession.Add(frame);
                    }
                    nativeSession.Stop(); Exporter.Write(nativeSession, Path.Combine(directory, "native-two-app-windows.zip"), true);
                    for (int i = 0; i < nativeSession.Steps.Count; i++) using (Bitmap bitmap = Exporter.WithFooter(nativeSession.Steps[i], nativeSession)) bitmap.Save(Path.Combine(directory, "native-window-" + (i + 1) + ".png"), ImageFormat.Png);
                }
                app.RefreshSteps(image.Id); app.SavePreview(Path.Combine(directory, "review-preview.png")); Size originalSize = app.Size; app.Size = new Size(1000, 700); app.SavePreview(Path.Combine(directory, "compact-preview.png")); app.Size = originalSize;
                app.Tabs.SelectedIndex = 1; app.SavePreview(Path.Combine(directory, "overview-preview.png"));
                Info("Existing v1 baseline: all 27 checks passed before changes; mandatory overview/window assumptions were intentionally replaced. See baseline-v1-results.txt.");
                Info("NOT VERIFIED: physical clicks/key events, real app focus switching, Windows Save As/Open dialog automation, multi-monitor and mixed DPI. Native hook registration status is above; input dispatch tests are not a physical desktop recording test.");
                ExitCode = 0;
            }
            catch (Exception ex) { results.Add(ex.ToString()); ExitCode = 1; }
            finally
            {
                foreach (Process p in new Process[] { a, b }) if (p != null) { try { if (!p.HasExited) p.Kill(); } catch { } p.Dispose(); }
                if (viewerPid != 0) try { using (Process p = Process.GetProcessById(viewerPid)) p.Kill(); } catch { }
                File.WriteAllLines(Path.Combine(directory, "test-results.txt"), results, new UTF8Encoding(false)); app.Dirty = false; app.Close();
            }
        }
        private static void Kill(int pid) { if (pid != 0) try { using (Process p = Process.GetProcessById(pid)) if (!p.HasExited) p.Kill(); } catch { } }
        private static async Task ViewerLoaded(int pid)
        {
            for (int i = 0; i < 40; i++) { await Task.Delay(80); if (WindowChoice.List().Any(w => w.Pid == pid && w.Title.Contains("grocery-fixture.txt"))) return; }
            throw new Exception("Late test viewer did not load the fixture.");
        }
    }
}
