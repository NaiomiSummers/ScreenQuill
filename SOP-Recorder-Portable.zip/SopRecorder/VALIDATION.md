# Validation — November 26, 2026

The existing app was inspected and updated in place. Its original 27 checks passed before changes; results are preserved in `tests/baseline-v1-results.txt`. Mandatory task details, mandatory window selection, and the manual screenshot hotkey flow were intentionally replaced by optional details and display recording.

The revised build compiles using the Windows Framework C# compiler with no package downloads. **66 revised checks passed** in the latest integration run; see [test-results.txt](tests/test-results.txt). The tests run on Windows, but this chat has no computer-use runtime for injecting physical input. These results do **not** claim a complete physical cross-app recording acceptance test.

## Actual native Windows checks

- Both low-level hooks registered successfully: mouse and keyboard available, Win32 error **0**.
- The primary display was enumerated at **1920 × 1080**, and native full-display acquisition returned those pixel dimensions. Its pixels were discarded after checking dimensions so unrelated desktop content is not included in the sample ZIPs.
- Two independent dummy application processes were launched. Their windows were enumerated, and native optional-window capture returned nonblank PNGs showing the actual controls and text. Both were visually inspected. `tests/native-two-app-windows.zip` contains these real native captures with correct timestamp footers and Markdown. This exercises window acquisition, not automatic display recording across physical app switches.
- The display picker and recording/review controls were exercised in process.
- A real dummy local text file was opened and displayed by the separate text viewer. Its canonical location was obtained from the handle used to read it and verified against the fixture. No path was inferred from a window title.
- Pending verified opens were revoked by Pause and Stop. Each delayed viewer subsequently loaded its file, but no late file evidence, path step, or metadata handoff remained.

## Trigger, cancellation, review and export checks

Transient test events exercise the same typing policy and screenshot queue used by the native hooks. Image fixtures for these checks are generated dummy frames, not physical desktop interactions. The live hook callback is intentionally excluded from dispatch during self-tests so a person using the computer cannot contaminate the results.

Checks cover one-click start with no overview, primary-display fallback, click captures, continuous typing, a fresh burst after idle, Tab during a burst, Tab followed immediately by typing after idle, Shift+Tab, held-key repeat suppression, modifier-only/shortcut exclusion, and recorder/out-of-scope exclusion. App switching is simulated in the display pipeline. Out-of-order completions are sorted by acquisition chronology.

Pause cancels a delayed capture; Stop cancels an in-flight capture. Neither allows additional steps or PNGs while disabled. Resume resets burst state. Late file opens are revoked independently from screenshot capture. Notes, reordered steps, removal/undo, editable/cleared paths, review invalidation, and refusal of unreviewed export are verified.

Evidence ZIPs were opened to check that they contain only the expected numbered PNGs and Markdown. Relative image references, final image ordering, edited notes/overview, reviewed-path status, and timestamp strings are checked against retained steps. Removed images and paths are absent; opened files and raw input logs are not bundled. Source review confirms no keyboard text conversion, clipboard read, or raw key serialization. Visible typed text can still appear in screenshot pixels, as intended.

The deterministic timing fixture uses **16 seconds elapsed, 12 seconds active, 4 seconds inactive**, with one deleted middle image and reversed export order. The retained timeline has **2 seconds before first**, **8 seconds between retained captures**, and **2 seconds after last**. The eight-second gap is correctly labeled as the longest interval in capture chronology. A wall-clock change does not alter durations. Image timestamp footers, review UI, and native captures were visually inspected.

Sample artifacts:

- `tests/automatic-workflow.zip`: generated display frames for dispatch/review/export tests.
- `tests/timing-and-deletion.zip`: deterministic timing and removal fixture.
- `tests/native-two-app-windows.zip`: real native screenshots from two dummy app processes.
- `tests/review-preview.png`, `tests/overview-preview.png`, `tests/footer-preview.png`, and `tests/native-window-1.png` / `2.png`: inspected previews.

## Still needs an interactive Windows acceptance run

Physical click/key delivery, actual display capture while switching between two normal apps, the native Open and Save As dialog interactions, multi-monitor selection changes, mixed DPI, elevated/protected apps and secure/locked desktops were **not** automated here. Native capture and hook installation passing separately do not establish physical event delivery end to end. The file test supplied the dummy filename directly to the viewer's same read/verify/display path; it did not click through the Windows Open dialog.

To finish those checks on Mom's computer:

1. Launch the app, leave task details blank, choose the intended display if needed, and click **Record Screen once**. Confirm it minimizes and records automatically.
2. Work in two apps using dummy content (for example, Notepad and File Explorer). Click once in each; confirm one delayed click screenshot each. Avoid recording private documents.
3. Type continuously, pause more than two seconds, and type again. Check one screenshot for the continuous burst and one for the new burst. In a form with two fields, try Tab then immediate typing after idle, and Shift+Tab during a burst. Confirm independent focus captures without changing the burst timer. Hold a key/Tab and check auto-repeat produces no extra captures.
4. While recording, use **Task details → Open text file with verified evidence...** and choose a dummy local `.txt` file. Confirm a file-open step with its verified path. Open a file normally in another app; confirm no unverified automatic full path is invented, and enter its path manually if desired.
5. Temporarily raise the click/Tab delay, click in another app and quickly Pause or Stop. Wait beyond the delay and confirm no new images. Resume and confirm the next typing burst captures afresh. Try pausing while the text viewer's Open dialog is pending; finish the open and confirm no late path step.
6. Stop, remove a screenshot, shorten/clear a path, reorder steps, add notes and optional overview, then export. Extract the ZIP and compare each image footer with its Markdown timestamp. Confirm removed material is absent and timing gaps still follow original capture chronology. Remember that clearing a path field does not redact a path visible in retained image pixels.

Launch and testing commands are in [README.md](README.md). Keep the test result distinction above when evaluating readiness: this is a working local prototype with tested components and integration, with physical Windows acceptance still outstanding.
